package com.example.aluno.readingshare.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.example.aluno.readingshare.R;

public class MainActivity extends AppCompatActivity {
        TextView tvCad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvCad= (TextView) findViewById(R.id.txtCad);

        tvCad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                irParaTelaCadastro();
            }
        });




    }

    public void irParaTelaLogin (View view){
        Intent intent1 = new Intent(getApplicationContext(), TelaLogin.class);
        startActivity(intent1);
    }

    public void irParaTelaCadastro(){
        Intent intent= new Intent(MainActivity.this,TelaCadastro.class);
        startActivity(intent);
    }
}
