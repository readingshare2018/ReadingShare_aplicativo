package com.example.aluno.readingshare.Activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import com.example.aluno.readingshare.Entidades.Usuarios;
import com.example.aluno.readingshare.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseException;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class TelaConfiguracoes extends AppCompatActivity {
    EditText txtNome;
    EditText txtEmail;
    EditText txtTelefone;
    EditText txtSenha;
    Button btnExcluir;
    private String id;
    List<Usuarios> usuarios;

    private FirebaseDatabase bd;
    private DatabaseReference referenceBd;

    private SharedPreferences sessao;
    private SharedPreferences.Editor finalizarSessao;
    private String codigo;

    FirebaseAuth firebaseAuth;
    FirebaseUser firebaseUser;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        usuarios = new ArrayList<>();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_configuracoes);

        inicializarFirebase();
        firebaseAuth= FirebaseAuth.getInstance();
        firebaseUser= firebaseAuth.getCurrentUser();
        txtNome = (EditText) findViewById(R.id.printNome);
        txtEmail = (EditText) findViewById(R.id.printEmail);
        txtTelefone = (EditText) findViewById(R.id.printTel);
        txtSenha = (EditText) findViewById(R.id.printSenha);
        btnExcluir = (Button) findViewById(R.id.btnExcluirUsuario);

        sessao = getSharedPreferences("dadosSessao", MODE_PRIVATE);
        finalizarSessao = sessao.edit();
        codigo = String.valueOf(sessao.getString("id", null));

        pesquisarUser();

        btnExcluir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteUser(codigo);
                firebaseUser.delete().addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful()){
                            Toast.makeText(TelaConfiguracoes.this,"Excluido com sucesso",Toast.LENGTH_LONG).show();
                            finish();
                            Intent intent= new Intent(TelaConfiguracoes.this,MainActivity.class);
                            startActivity(intent);
                        }
                    }
                });

                }

        });
    }

    private void deleteUser(String idUser){
        DatabaseReference drUsuario= FirebaseDatabase.getInstance().getReference("usuarios").child(idUser);
        DatabaseReference drlivro= FirebaseDatabase.getInstance().getReference("livros").child(idUser);

        drUsuario.removeValue();
        drlivro.removeValue();
    }

    public void pesquisarUser(){
        Query q = referenceBd.child("usuarios").orderByChild("id");
        q.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                usuarios.clear();
                for (DataSnapshot postSnapShot : dataSnapshot.getChildren()) {
                    Usuarios user = postSnapShot.getValue(Usuarios.class);
                    usuarios.add(user);
                }

                for(int i = 0; i < usuarios.size(); i++){
                    if(usuarios.get(i).getId().equals(sessao.getString("id", "vazio"))){
                        txtNome.setText(usuarios.get(i).getNome());
                        txtEmail.setText(usuarios.get(i).getEmail());
                        txtTelefone.setText(usuarios.get(i).getTelefone());
                        txtSenha.setText(usuarios.get(i).getSenha());
                    }
                }
            }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(TelaConfiguracoes.this, databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void inicializarFirebase(){
        FirebaseApp.initializeApp(TelaConfiguracoes.this);
        bd = FirebaseDatabase.getInstance("https://readingshare2.firebaseio.com/");
        referenceBd = bd.getReference();
    }

}
