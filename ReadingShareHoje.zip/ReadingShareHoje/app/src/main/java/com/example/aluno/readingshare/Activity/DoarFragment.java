package com.example.aluno.readingshare.Activity;

import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.aluno.readingshare.Entidades.Livro;
import com.example.aluno.readingshare.Entidades.Upload;
import com.example.aluno.readingshare.Entidades.Usuarios;
import com.example.aluno.readingshare.R;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.util.HashMap;
import java.util.List;

import static android.app.Activity.RESULT_OK;

public class DoarFragment extends Fragment implements AdapterView.OnItemSelectedListener{
    private EditText txtTituloLivro;
    private EditText txtAutorLivro;
    private Spinner spinnerLivro;
    private EditText txtSinopseLivro;
    private String imagemLivro;
    private Button btnAddLivro;
    private ImageView profileImage;
    private Livro livro;
    private String codigo;
    private List<Upload> muploads;
    private StorageReference mStorageRef;
    private StorageTask mUploadTask;
    private SharedPreferences sessao;
    private FirebaseAuth autenticacao;
    private FirebaseDatabase bd;
    private DatabaseReference referenceBd;

    final static int Gallery_Pick = 1;
    private Uri imageUri;

    @Nullable
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_doar, container, false);
        inicializarFirebase();
        txtTituloLivro= (EditText)v.findViewById(R.id.txtTituloLivro);
        txtAutorLivro= (EditText)v.findViewById(R.id.txtAutorLivro);
        spinnerLivro= (Spinner)v.findViewById(R.id.spinnerLivro);
        txtSinopseLivro= (EditText)v.findViewById(R.id.txtSinopseLivro);
        profileImage = (ImageView) v.findViewById(R.id.profileSetup);
        mStorageRef = FirebaseStorage.getInstance().getReference();
        referenceBd = FirebaseDatabase.getInstance().getReference();
        btnAddLivro= (Button)v.findViewById(R.id.btnAddLivro);
        sessao = this.getContext().getSharedPreferences("dadosSessao",Context.MODE_PRIVATE);
        codigo= String.valueOf(sessao.getString("id",null));
        imagemLivro = "imagem inválida";


        btnAddLivro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               // uploadFile();
                addLivro();
            }
        });

        profileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent galleryIntent = new Intent();
                galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
                galleryIntent.setType("image/*");
                startActivityForResult(galleryIntent, Gallery_Pick);
            }
        });

        return v;
    }

    /*private void carregarImagem() {
        Query query = referenceBd.child("Uploads").orderByChild("mName");
        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                for(DataSnapshot postSnapShot : dataSnapshot.getChildren()){
                    Upload upload = postSnapShot.getValue(Upload.class);
                    muploads.add(upload);
                }
                for(int i = 0; i < muploads.size(); i++){
                    if(muploads.get(i).getmName().equals(sessao.getString("nome", "vazio"))){
                        Picasso.with(getActivity()).load(muploads.get(i).getmImageUrl())
                                .fit().into(profileImage);
                    }
                }
                profileImage.setVisibility(View.VISIBLE);
            }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getActivity(), databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }*/

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==Gallery_Pick && resultCode==RESULT_OK && data!=null && data.getData() != null){
            imageUri = data.getData();
            Picasso.with(getActivity()).load(imageUri).into(profileImage);
        }
    }

    private String getFileExtension(Uri uri){
        ContentResolver cR = getActivity().getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cR.getType(uri));
    }

   private void uploadFile(){
        if(imageUri != null){
            final StorageReference fileReference = mStorageRef.child("livros").child(codigo + "/" + System.currentTimeMillis()+"."+getFileExtension(imageUri));
            fileReference.putFile(imageUri).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                @Override
                public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                    if(!task.isSuccessful()){
                        throw task.getException();
                    }
                    return fileReference.getDownloadUrl();
                }
            }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                @Override
                public void onComplete(@NonNull Task<Uri> task) {
                    if(task.isSuccessful()){
                        Uri downloadUri = task.getResult();
                        imagemLivro = downloadUri.toString();
                        //Toast.makeText(getActivity(), imagemLivro, Toast.LENGTH_SHORT).show();
                        addLivro();
                        /*Upload upload = new Upload(txtTituloLivro, downloadUri.toString());
                        String uploadId = referenceBd.child("livros").child(codigo).push().getKey();
                        referenceBd.child("livros").child(codigo).child(uploadId).setValue(upload);*/
                    }else {
                        Toast.makeText(getActivity(), "upload failed: "+ task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }else{
            Toast.makeText(getActivity(), "No file selected", Toast.LENGTH_SHORT).show();
        }
    }

    private void limparTxt(){
        txtTituloLivro.setText("");
        txtAutorLivro.setText("");
        txtSinopseLivro.setText("");
    }


    private void addLivro() {
        String id;
        String tituloLivro, autorLivro, generoLivro, sinopseLivro;
        tituloLivro = txtTituloLivro.getText().toString();
        autorLivro = txtAutorLivro.getText().toString();
        generoLivro = spinnerLivro.getSelectedItem().toString();
        sinopseLivro = txtSinopseLivro.getText().toString();
        Livro livro = new Livro();

        livro.setTitulo(tituloLivro);
        livro.setId(String.valueOf(livro.getTitulo().hashCode()));
        livro.setAutor(autorLivro);
        livro.setGenero(generoLivro);
        livro.setSinopse(sinopseLivro);
        livro.setIdUser(codigo);
        livro.setImagem(imagemLivro);
        //referenceBd.child("livros").child(codigo).child(String.valueOf(livro.getTitulo().hashCode())).setValue(livro);
        //referenceBd.child("livrosgeral").child(String.valueOf(livro.getTitulo().hashCode())).setValue(livro);

        if (!TextUtils.isEmpty(generoLivro)) {
            referenceBd.child("livros").child(codigo).child(String.valueOf(livro.getTitulo().hashCode())).setValue(livro);
            referenceBd.child("livrosgeral").child(String.valueOf(livro.getTitulo().hashCode())).setValue(livro);
            Toast.makeText(getContext(), "Livro adicionado com sucesso", Toast.LENGTH_LONG).show();
            limparTxt();
        } else {
            Toast.makeText(getContext(), "Escolha um genero", Toast.LENGTH_LONG);
        }
    }

    private void inicializarFirebase() {
        FirebaseApp.initializeApp(getContext());
        bd = FirebaseDatabase.getInstance("https://readingshare2.firebaseio.com/");
        referenceBd = bd.getReference();
    }
    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}
