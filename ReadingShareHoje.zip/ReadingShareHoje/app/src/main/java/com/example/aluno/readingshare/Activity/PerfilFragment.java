package com.example.aluno.readingshare.Activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.example.aluno.readingshare.R;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class PerfilFragment extends Fragment {
    private Button btnConfigTela;
    private Button btnSair;
    private Button btnSobrePerfil;
    private Button btnMeuPerfil;
    private Button btnMeusLivros;
    private Button getBtnSair;
    FirebaseAuth auth;
    FirebaseDatabase bd;
    DatabaseReference referenceBd;
    private SharedPreferences sessao;
    private SharedPreferences.Editor finalizarSessao;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_perfil, container, false);

        auth = FirebaseAuth.getInstance();
        inicializarFirebase();

        btnConfigTela = (Button) v.findViewById(R.id.btnConfigTela);
        btnSobrePerfil = (Button) v.findViewById(R.id.btnSobrePerfil);
        btnSair = (Button) v.findViewById(R.id.btnSair);
        btnMeuPerfil = (Button) v.findViewById(R.id.btnMeuPerfil);
        btnMeusLivros = (Button) v.findViewById(R.id.btnMeusLivros);

        //sessao = getSharedPreferences("dadosSessao", getBaseContext().MODE_PRIVATE);
        //finalizarSessao = sessao.edit();

        btnConfigTela.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), TelaConfiguracoes.class);
                getContext().startActivity(intent);
            }
        });

        btnSair.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), MainActivity.class);
                getContext().startActivity(intent);
            }
        });

        btnSobrePerfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), TelaSobre.class);
                getContext().startActivity(intent);
            }
        });

        btnMeuPerfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), Meuperfil.class);
                getContext().startActivity(intent);
            }
        });

        btnMeusLivros.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), MeusLivros.class);
                getContext().startActivity(intent);
            }
        });

        /*btnSair.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                auth.
            }
        });

    */
        return v;
    }

        private void inicializarFirebase(){
            FirebaseApp.initializeApp(getActivity());
            bd = FirebaseDatabase.getInstance("https://readingshare2.firebaseio.com");
            referenceBd = bd.getReference();
        }

    }


