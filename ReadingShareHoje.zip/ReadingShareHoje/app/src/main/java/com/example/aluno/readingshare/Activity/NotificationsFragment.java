package com.example.aluno.readingshare.Activity;

import android.content.Context;
import android.content.SharedPreferences;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.aluno.readingshare.Entidades.Livro;
import com.example.aluno.readingshare.Entidades.Usuarios;
import com.example.aluno.readingshare.R;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class NotificationsFragment extends Fragment {
    private FirebaseDatabase bd2;
    private DatabaseReference referenceBd2;
    private ListView lvLivros;
    private ArrayList listNomeLivro;
    private ArrayList<Livro> listLivro;
    private String codigo;
    private SharedPreferences sessao;
    private SensorManager mSensorManager;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
       final View v= inflater.inflate(R.layout.fragment_notifications,container, false);
        sessao = this.getContext().getSharedPreferences("dadosSessao",Context.MODE_PRIVATE);
        codigo= String.valueOf(sessao.getString("id",null));
        lvLivros = (ListView) v.findViewById(R.id.lvLivros);
        listNomeLivro = new ArrayList<String>();
        listLivro = new ArrayList<>();
        inicializarFirebase();

        Query q = referenceBd2.child("livrosgeral");
        listLivro.clear();

        q.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot obj : dataSnapshot.getChildren()) {
                    Livro livro = obj.getValue(Livro.class);
                    if (codigo.compareTo(livro.getIdUser()) != 0) {
                        listLivro.add(livro);
                    }
                }
                //Toast.makeText(getContext(), "Tamanho:"+String.valueOf(listLivro.size()), Toast.LENGTH_LONG).show();
                for(int i = 0; i < listLivro.size(); i++){

                    listNomeLivro.add(listLivro.get(i).getTitulo());
                }

                 ArrayAdapter<String> adapterEvento = new ArrayAdapter<String>(v.getContext(), android.R.layout.simple_list_item_1, listNomeLivro);

                lvLivros.setAdapter(adapterEvento);

                lvLivros.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                       View v = getLayoutInflater().inflate(R.layout.recycler_livros, null);
                        TextView lNome = (TextView) v.findViewById(R.id.lTitulo);
                        TextView lAutor = (TextView) v.findViewById(R.id.lAutor);
                        TextView lGenero = (TextView) v.findViewById(R.id.lGenero);
                        TextView lSinopse = (TextView) v.findViewById(R.id.lSinopse);

                        final TextView lnomeDoador= (TextView) v.findViewById(R.id.lNomeUser);
                        final TextView lTelDoador=(TextView)v.findViewById(R.id.lTelUser);

                        final String idUsuarioDoador;
                        Query q = referenceBd2.child("usuarios").child(listLivro.get(i).getIdUser());
                        q.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                Usuarios usuario= dataSnapshot.getValue(Usuarios.class);
                                lnomeDoador.setText("Nome doador:"+usuario.getNome());
                                lTelDoador.setText("Telefone Doador:"+usuario.getTelefone());
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                        lNome.setText("Titulo:"+listLivro.get(i).getTitulo());
                        lAutor.setText("Autor:"+listLivro.get(i).getAutor());
                        lGenero.setText("Genero:"+listLivro.get(i).getGenero());
                        lSinopse.setText("Sinopse:"+listLivro.get(i).getSinopse());


                        AlertDialog.Builder bDados = new AlertDialog.Builder(getActivity());

                        bDados.setTitle("Informacoes do livro:");
                        bDados.setView(v);
                        bDados.setCancelable(true);

                        AlertDialog dados = bDados.create();

                        dados.show();
                    }
                });

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        return v;
    }

    private void inicializarFirebase() {
        FirebaseApp.initializeApp(getContext());
        bd2 = FirebaseDatabase.getInstance("https://readingshare2.firebaseio.com/");
        referenceBd2 = bd2.getReference();
    }
}
