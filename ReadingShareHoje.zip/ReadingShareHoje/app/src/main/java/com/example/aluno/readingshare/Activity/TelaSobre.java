package com.example.aluno.readingshare.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.aluno.readingshare.R;

public class TelaSobre extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_sobre);
    }
}
