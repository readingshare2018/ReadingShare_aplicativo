package com.example.aluno.readingshare.Activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.aluno.readingshare.DAO.ConfiguracaoFirebase;
import com.example.aluno.readingshare.Entidades.Usuarios;
import com.example.aluno.readingshare.Helper.Base64Custom;
import com.example.aluno.readingshare.Helper.Preferencias;
import com.example.aluno.readingshare.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;

public class TelaCadastro extends AppCompatActivity {
    private EditText txtNomeCad;
    private EditText txtEmailCad;
    private EditText txtTelefoneCad;
    private EditText txtSenhaCad;
    private Button btnCadastro;
    private Usuarios user;

    private FirebaseAuth autenticacao;
    DatabaseReference databaseUsuarios;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_cadastro);

        txtNomeCad= (EditText)findViewById(R.id.txtNomeCad);
        txtEmailCad= (EditText) findViewById(R.id.txtEmailCad);
        txtTelefoneCad= (EditText) findViewById(R.id.txtTelefoneCad);
        txtSenhaCad= (EditText) findViewById(R.id.txtSenhaCad);
        btnCadastro= (Button) findViewById(R.id.btnCadastro);
        databaseUsuarios= FirebaseDatabase.getInstance().getReference("usuarios");

        btnCadastro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cadastrarUsuario();
            }
        });
    }

    private void cadastrarUsuario(){

        String nome, email, telefone, senha;
        nome = txtNomeCad.getText().toString();
        email = txtEmailCad.getText().toString();
        String id = String.valueOf(email.hashCode());
        telefone = txtTelefoneCad.getText().toString();
        senha = txtSenhaCad.getText().toString();
        Usuarios user = new Usuarios();
        user.setId(id);
        user.setNome(nome);
        user.setEmail(email);
        user.setTelefone(telefone);
        user.setSenha(senha);

        databaseUsuarios.child(id).setValue(user);
        autenticacao= FirebaseAuth.getInstance();
        autenticacao.createUserWithEmailAndPassword(
                user.getEmail(),
                user.getSenha()
        ).addOnCompleteListener(TelaCadastro.this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()){
                    Toast.makeText(TelaCadastro.this, "Usuario cadastrado com sucesso",Toast.LENGTH_LONG).show();
                    abrirLogin();
                }else{
                    String erro= "";
                    try {
                        throw task.getException();
                    }catch (FirebaseAuthWeakPasswordException e){
                        erro= "Digite uma senha mais forte";
                    }catch (FirebaseAuthInvalidCredentialsException e){
                        erro="O email e invalido";
                    }catch (FirebaseAuthUserCollisionException e ){
                        erro=" Esse email ja foi cadastrado";
                    }catch (Exception e ){
                        erro= "Cadastro invalido";
                        e.printStackTrace();
                    }

                    Toast.makeText(TelaCadastro.this, "Erro:"+erro,Toast.LENGTH_LONG).show();
                }
            }
        });


    }

    public void abrirLogin(){
        Intent intent = new Intent(TelaCadastro.this,TelaLogin.class);
        startActivity(intent);
        finish();
    }
}
