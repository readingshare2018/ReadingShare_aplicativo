package com.example.aluno.readingshare.Helper;
import android.content.Context;
import android.content.SharedPreferences;
public class Preferencias {
    private Context context;
    private SharedPreferences preferences;
    private String NOME_ARQUIVO = "ReadingShare2.preferencias";
    private int MODE= 0;
    private SharedPreferences.Editor editor;

    private final String CHAVE_IDENTIFICADOR= "identificarUsuarioLogado";
    private final String CHAVE_NOME= "nomeUsuarioLogado";

    public Preferencias(Context context) {
        this.context = context;
        preferences= context.getSharedPreferences(NOME_ARQUIVO,Context.MODE_PRIVATE);
        editor= preferences.edit();
    }

    public void salvarUsuarioPreferencias(String identificador, String nome){
            editor.putString(CHAVE_IDENTIFICADOR,identificador);
            editor.putString(CHAVE_NOME,nome);
            editor.commit();
    }

    public String getIdentificador(){
        return preferences.getString(CHAVE_IDENTIFICADOR,null);
    }

    public  String getNome(){
        return preferences.getString(CHAVE_NOME,null);
    }
}
