package com.example.aluno.readingshare.Entidades;

import com.example.aluno.readingshare.DAO.ConfiguracaoFirebase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.Exclude;

import java.util.HashMap;
import java.util.Map;

public class Usuarios  {
    private String id;
    private String nome;
    private String email;
    private String telefone;
    private String senha;


    public Usuarios() {
    }
    public String getId(){
        return id;
    }

    public void setId(String id){
        this.id=id;
    }



    public String getNome(){
        return nome;
    }
    public void setNome(String nome){
        this.nome=nome;
    }

    public String getEmail() {
        return email;
    }
    public String getTelefone(){
        return telefone;
    }

    public void setTelefone(String telefone){
        this.telefone=telefone;
    }
    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
}
