package com.example.aluno.readingshare.Activity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.example.aluno.readingshare.Entidades.Livro;
import com.example.aluno.readingshare.Entidades.Usuarios;
import com.example.aluno.readingshare.R;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MeusLivros extends AppCompatActivity {

    private FirebaseDatabase bd3;
    private DatabaseReference referenceBd3;
    private ListView lvLivros2;
    private ArrayList listNomeLivro2;
    private ArrayList<Livro> listLivro2;
    private String codigo;
    private SharedPreferences sessao;
    private SensorManager mSensorManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.meus_livros);

        sessao = this.getSharedPreferences("dadosSessao", Context.MODE_PRIVATE);
        codigo= String.valueOf(sessao.getString("id",null));
        lvLivros2 = (ListView) findViewById(R.id.lvLivros2);
        listNomeLivro2 = new ArrayList<String>();
        listLivro2 = new ArrayList<>();
        inicializarFirebase();

        Query q = referenceBd3.child("livrosgeral");
        listLivro2.clear();

        q.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot obj : dataSnapshot.getChildren()) {
                    Livro livro = obj.getValue(Livro.class);
                    if (codigo.compareTo(livro.getIdUser()) == 0) {
                        listLivro2.add(livro);
                    }
                }
                //Toast.makeText(getContext(), "Tamanho:"+String.valueOf(listLivro.size()), Toast.LENGTH_LONG).show();
                for (int i = 0; i < listLivro2.size(); i++) {

                    listNomeLivro2.add(listLivro2.get(i).getTitulo());
                }

                ArrayAdapter<String> adapterEvento = new ArrayAdapter<String>(MeusLivros.this, android.R.layout.simple_list_item_1, listNomeLivro2);

                lvLivros2.setAdapter(adapterEvento);

                lvLivros2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                        View v = getLayoutInflater().inflate(R.layout.recycler_livros2, null);

                        Button btnExcluirLivro = (Button) v.findViewById(R.id.btnExcluirLivro);
                        TextView lNome = (TextView) v.findViewById(R.id.lTitulo2);
                        TextView lAutor = (TextView) v.findViewById(R.id.lAutor2);
                        TextView lGenero = (TextView) v.findViewById(R.id.lGenero2);
                        TextView lSinopse = (TextView) v.findViewById(R.id.lSino2);

                        lNome.setText("Titulo:"+listLivro2.get(i).getTitulo());
                        lAutor.setText("Autor:"+listLivro2.get(i).getAutor());
                        lGenero.setText("Genero:"+listLivro2.get(i).getGenero());
                        lSinopse.setText("Sinopse:"+listLivro2.get(i).getSinopse());
                        final String titulo = listLivro2.get(i).getTitulo();



                        AlertDialog.Builder bDados = new AlertDialog.Builder(MeusLivros.this);

                        bDados.setTitle("Informacoes do livro:");
                        bDados.setView(v);
                        bDados.setCancelable(true);

                        AlertDialog dados = bDados.create();

                        dados.show();
                        btnExcluirLivro.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                DatabaseReference drlivro= FirebaseDatabase.getInstance().getReference("livrosgeral").child(String.valueOf(titulo.hashCode()));
                                DatabaseReference drlivro2= FirebaseDatabase.getInstance().getReference("livros").child(codigo).child(String.valueOf(titulo.hashCode()));
                                drlivro.removeValue();
                                drlivro2.removeValue();
                                listNomeLivro2.clear();
                                listLivro2.clear();
                            }
                        });


                    }
                });

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });



    }

    private void inicializarFirebase() {
        FirebaseApp.initializeApp(MeusLivros.this);
        bd3 = FirebaseDatabase.getInstance("https://readingshare2.firebaseio.com/");
        referenceBd3 = bd3.getReference();
    }
}


