package com.example.aluno.readingshare.Activity;

import android.content.Context;
import android.content.SharedPreferences;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.example.aluno.readingshare.Entidades.Livro;
import com.example.aluno.readingshare.Entidades.Usuarios;
import com.example.aluno.readingshare.R;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class FriendsFragment extends Fragment {

    private FirebaseDatabase bd3;
    private DatabaseReference referenceBd3;
    private ListView lvUsuarios;
    private ArrayList listNomeUsuario;
    private ArrayList<Usuarios> listUsuario;
    private String codigo;
    private SharedPreferences sessao;
    private SensorManager mSensorManager;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        final View v= inflater.inflate(R.layout.fragment_friends,container, false);
        sessao = this.getContext().getSharedPreferences("dadosSessao",Context.MODE_PRIVATE);
        codigo= String.valueOf(sessao.getString("id",null));
        lvUsuarios = (ListView) v.findViewById(R.id.lvUsuarios);
        listNomeUsuario = new ArrayList<String>();
        listUsuario = new ArrayList<>();
        inicializarFirebase();

        Query q = referenceBd3.child("usuarios");
        listUsuario.clear();

        q.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot obj : dataSnapshot.getChildren()) {
                    Usuarios user = obj.getValue(Usuarios.class);
                    if (codigo.compareTo(user.getId()) != 0) {
                        listUsuario.add(user);
                    }
                }
                //Toast.makeText(getContext(), "Tamanho:"+String.valueOf(listLivro.size()), Toast.LENGTH_LONG).show();
                for(int i = 0; i < listUsuario.size(); i++){

                    listNomeUsuario.add(listUsuario.get(i).getNome());
                }

                ArrayAdapter<String> adapterEvento = new ArrayAdapter<String>(v.getContext(), android.R.layout.simple_list_item_1, listNomeUsuario);

                lvUsuarios.setAdapter(adapterEvento);

                lvUsuarios.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                         final View v = getLayoutInflater().inflate(R.layout.recycler_usuarios, null);
                        TextView lNome = (TextView) v.findViewById(R.id.lnomeUsuario);
                        TextView lemail = (TextView) v.findViewById(R.id.lemailUsuario);
                        TextView ltelefone = (TextView) v.findViewById(R.id.ltelefoneUsuario);


                        lNome.setText("Nome:"+listUsuario.get(i).getNome());
                        lemail.setText("Email:"+listUsuario.get(i).getEmail());
                        ltelefone.setText("Telefone:"+listUsuario.get(i).getTelefone());



                        AlertDialog.Builder bDados = new AlertDialog.Builder(getActivity());

                        bDados.setTitle("Informacoes do Usuario:");
                        bDados.setView(v);
                        bDados.setCancelable(true);

                        AlertDialog dados = bDados.create();

                        dados.show();
                    }
                });

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        return v;
    }

    private void inicializarFirebase() {
        FirebaseApp.initializeApp(getContext());
        bd3 = FirebaseDatabase.getInstance("https://readingshare2.firebaseio.com/");
        referenceBd3 = bd3.getReference();
    }
}
