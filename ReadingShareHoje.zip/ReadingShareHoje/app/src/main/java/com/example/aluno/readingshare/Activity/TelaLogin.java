package com.example.aluno.readingshare.Activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.aluno.readingshare.DAO.ConfiguracaoFirebase;
import com.example.aluno.readingshare.Entidades.Usuarios;
import com.example.aluno.readingshare.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

/**
 * Created by Aluno on 08/10/2018.
 */

public class TelaLogin extends AppCompatActivity{
    Button btnLogin;
    EditText txtEmail;
    EditText txtSenha;
    private FirebaseAuth autenticacao;
    private FirebaseDatabase bd;
    private DatabaseReference referenceBd;
    private Usuarios usuarios;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_login);
        inicializarFirebase();
        txtEmail = (EditText) findViewById(R.id.txtEmail);
        txtSenha = (EditText) findViewById(R.id.txtSenha);
        btnLogin = (Button) findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!txtEmail.getText().toString().equals("") && !txtSenha.getText().toString().equals("")){
                    usuarios = new Usuarios();
                    usuarios.setEmail(txtEmail.getText().toString());
                    usuarios.setSenha(txtSenha.getText().toString());
                    usuarios.setId(String.valueOf(usuarios.getEmail().hashCode()));

                    validarLogin();
                }else{
                    Toast.makeText(TelaLogin.this, "Preencha todos os dados!", Toast.LENGTH_SHORT).show();
                }
            }
        });
        //txtEmail.setText();
        //txtSenha.setText();
        //btnLogin.setOnClickListener();

    }
    private void validarLogin(){
        autenticacao = ConfiguracaoFirebase.getFirebaseAutenticacao();
        autenticacao.signInWithEmailAndPassword(usuarios.getEmail(), usuarios.getSenha()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){

                    SharedPreferences dadosSessao= getSharedPreferences("dadosSessao",MODE_PRIVATE);
                    SharedPreferences.Editor sessao= dadosSessao.edit();
                    sessao.putString("id",usuarios.getId());
                    sessao.putString("email",usuarios.getEmail());
                    sessao.commit();
                    abrirTelaUsuario();
                    Toast.makeText(TelaLogin.this, "Login efetuado com sucesso", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(TelaLogin.this, "Email ou senha invalidos!", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
    private void inicializarFirebase() {
        FirebaseApp.initializeApp(TelaLogin.this);
        bd = FirebaseDatabase.getInstance("https://readingshare2.firebaseio.com/");
        referenceBd = bd.getReference();
    }
    public void abrirTelaUsuario(){
        Bundle bundle = new Bundle();
        bundle.putString("idUser", usuarios.getId());
        Intent intent = new Intent(TelaLogin.this, TelaUsuario.class);
        intent.putExtras(bundle);
        startActivity(intent);
    }
}
